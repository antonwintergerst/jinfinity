<?php
/**
 * @version     $Id: separator.php 037 2013-10-25 13:00:00Z Anton Wintergerst $
 * @package     Jinfinity Migrator for Joomla 1.5+
 * @copyright   Copyright (C) 2013 Jinfinity. All rights reserved.
 * @license     GNU/GPLv3 http://www.gnu.org/licenses/gpl-3.0.html
 * @website     www.jinfinity.com
 * @email       support@jinfinity.com
 */

// no direct access
defined('_JEXEC') or die('Restricted access');

class JiMigratorFieldSeparator extends JiMigratorField {
    function renderInput() {
        $html = '<span class="jiseparator">';
        if($this->get('label')!=null) $html.= $this->get('label');
        $html.= '</span>';
        
        return $html;
    }
    function renderInputLabel() {
        return;
    }
}
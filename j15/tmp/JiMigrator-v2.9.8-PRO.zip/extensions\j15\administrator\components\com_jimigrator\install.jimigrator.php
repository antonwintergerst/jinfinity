<?php 
/**
 * @version		$Id: install.jinfinity.php 015 2014-12-12 13:40:00Z Anton Wintergerst $
 * @package		Jinfinity Migrator for Joomla 1.5 only
 * @copyright	Copyright (C) 2014 Jinfinity. All rights reserved.
 * @license		GNU/GPLv3 http://www.gnu.org/licenses/gpl-3.0.html
 * @website		www.jinfinity.com
 * @email		support@jinfinity.com
*/

// no direct access
defined('_JEXEC') or die('Restricted access');

jimport('joomla.installer.installer');
$lang = JFactory::getLanguage();
$lang->load('com_jimigrator');

// Remove front-end parts
jimport('joomla.filesystem.folder');
if(JFolder::exists(JPATH_SITE.'/components/com_jimigrator')) rmdir(JPATH_SITE.'/components/com_jimigrator');
?>
<link href="<?php echo JURI::root(true).'/media/jimigrator/css/jimigrator.css'; ?>" rel="stylesheet" media="screen">
<div class="jiadmin jinstaller jimigrator">
    <div class="items actions">
        <div class="item">
            <span class="item-image"><img src="<?php echo JURI::root(); ?>media/jimigrator/images/jimigrator-importicon.png" /></span>
            <div class="item-text">
                <a class="btn btn-large btn-outline item-title" href="index.php?option=com_jimigrator&view=import">
                    <span><?php echo JText::_('JIMIGRATOR_IMPORT'); ?></span>
                </a>
                <p><?php echo JText::_('JIMIGRATOR_IMPORT_DESC'); ?></p>
            </div>
        </div>
        <div class="item">
            <span class="item-image"><img src="<?php echo JURI::root(); ?>media/jimigrator/images/jimigrator-exporticon.png" /></span>
            <div class="item-text">
                <a class="btn btn-large btn-outline item-title" href="index.php?option=com_jimigrator&view=export">
                    <span><?php echo JText::_('JIMIGRATOR_EXPORT'); ?></span>
                </a>
                <p><?php echo JText::_('JIMIGRATOR_EXPORT_DESC'); ?></p>
            </div>
        </div>
    </div>
</div>
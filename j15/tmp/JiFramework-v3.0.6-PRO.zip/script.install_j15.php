<?php
/**
 * @version     $Id: script.install.php 033 2014-12-12 15:08:00Z Anton Wintergerst $
 * @package     Jinfinity Installer for Joomla 3.x
 * @copyright   Copyright (C) 2014 Jinfinity. All rights reserved.
 * @license     GNU/GPLv3 http://www.gnu.org/licenses/gpl-3.0.html
 * @website     www.jinfinity.com
 * @email       support@jinfinity.com
 */

// no direct access
defined('_JEXEC') or die;
if(!defined('INSTALLER_ROOT')) define('INSTALLER_ROOT', dirname(__FILE__));
require_once(INSTALLER_ROOT.'/script.install.php');
$installer = new Com_JiInstallerInstallerScript();
$installer->preflight(null, null);